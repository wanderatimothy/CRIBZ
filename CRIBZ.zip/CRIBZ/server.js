const express = require('express');
const bodyparser = require('body-parser');
const session = require('express-session');
const path = require('path');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');
const PORT_NUMBER = 4000;
const SALT = 78391;


const app = new express();

const con = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
    database : "cribz"

});

app.use(bodyparser.urlencoded({extended:true}));
app.set('view engine','ejs');
app.use('/dist',express.static(path.join(__dirname,'/node_modules/jquery/dist')));
app.use('/js',express.static(path.join(__dirname,'/node_modules/materialize-css/dist/js')));
app.use('/css',express.static(path.join(__dirname,'/node_modules/materialize-css/dist/css')));
app.use(session({
    name:'',
    resave:false,
    saveUninitialized:false,
    secret:'Emblemz of time',
    //store:mysql,
    cookie:{
        maxAge: 1,
        sameSite: true,
        secure:false
    }

}));
const redirectLogin = (req,res,next) => {
    if(req.session.name === ''){
        res.redirect('/forms');
    }
    else{
        next();
    }
}

app.get('/',(req,res)=>{
   console.log('Request from :: '+ req.url);
    res.render('Landing', {siteTitle:"CRIBZ",description:"Get the best residence or condominion you are worth !!"});

});
app.get('/Hotels',(req,res)=>{
    console.log('Request from :: '+ req.url);

});
app.get('/Resorts',(req,res)=>{
    console.log('Request from :: '+ req.url);

});
app.get('/Lodges',(req,res)=>{
    console.log('Request from :: '+ req.url);

});
app.get('/apartments',(req,res)=>{
    console.log('Request from :: '+ req.url);

});
app.get('/forms',(req,res)=>{
    console.log('Request from :: '+ req.url);
    res.render('forms',{error:''});
});
app.post('/signUp',(req,res)=>{
    console.log('Request from :: '+ req.url);
    bcrypt.genSalt(10,(err,SALT)=>{
        var pasword = req.body.password_confirm;
        bcrypt.hash(pasword,SALT,(err,hash)=>{
            var query = `INSERT INTO users (user_email,user_name,user_password,session_access_counter,Tellcontact,NIN,profilepic,start_date)
            VALUES ('${req.body.user_email}','${req.body.user_name}','${hash}','${0}','0','0','0','CURRENT_TIMESTAMP')`;
            
            con.query(query,(err,result)=>{
                if(err){ throw err; console.log(err) }
                res.render('success');
            });
        });

    });
    
});

app.post('/login',(req,res)=>{
    console.log('Request from :: '+ req.url);
    bcrypt.genSalt(10,(err,SALT)=>{
        bcrypt.hash(req.body.UserPassword,SALT,(err , hash)=>{
            var fetch =`SELECT * FROM users WHERE user_email = '${req.body.UserEmail}' AND user_password='${hash}'`;
            con.query(fetch,(err,result)=>{
                if(err){console.log(err); res.render('/forms',{error:"username or password incorect"});}
                else{ 
                    req.session.name = result.user.user_name;
                   let data = {
                        Userid : result.user_email,
                        Username: result.user_name,
                        session_Count:result.session_access_counter,
                        user_type :'',
                        login_status : true,
                    };
                     switch (data.user_type)
                     {
                        case "ADMIN":
                        res.render("AdminHome",data);
                        break;
                        case "VISTOR":
                        res.render("vistorHome",data);
                        break;
                        case "VFXGUY":
                        res.render("vfxHome",data);
                        break;
                        default:
                        res.send("404",data);
                        console.log(`WHO ARE YOU ${data.user_type} WHAT YOU WANT ${data.Username}`);
                        
                     }
                    
                }
            });
        });
    });
    
});

app.get('/AdminHome', redirectLogin, (req,res)=>{

});
app.get('/vistorHome', redirectLogin, (req,res)=>{

});
app.get('/vfxHome', redirectLogin, (req,res)=>{

});

app.listen(PORT_NUMBER);
console.log('your app is  running on port number' + PORT_NUMBER);